/*
* @author: Richard Kiddle 18/11/20
* @desciption: Prints Hello World
*
*  */

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World");
    }
}
